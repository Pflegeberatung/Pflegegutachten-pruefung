---
name: pflegegutachten-pruefung
description: Prüft Pflegegutachten des Medizinischen Dienstes (MD) oder von Medicproof nach dem Neuen Begutachtungsassessment (NBA) Modul für Modul, rechnet die Punkte nach und erstellt einen Widerspruch, eine Stellungnahme oder einen Höherstufungsantrag als Word-Datei. Verwenden, wenn jemand ein Pflegegutachten, einen Pflegegrad-Bescheid oder eine Anhörung zur Herabstufung prüfen oder anfechten möchte.
---

# Pflegegutachten prüfen (NBA, SGB XI)

## Wichtiger Hinweis (immer beachten)
Dieser Skill ist eine **Hilfe zur Selbsthilfe** für Versicherte, Angehörige, gesetzliche Betreuer und Pflegeberater. Er ist **keine Rechtsberatung** und ersetzt keine Beratung durch einen Fachanwalt für Sozialrecht, einen Sozialverband (z. B. VdK, SoVD) oder einen Pflegestützpunkt. Diesen Hinweis einmal zu Beginn der Antwort kurz nennen. Bei Klage, versäumter Frist oder unklarer Rechtslage ausdrücklich auf diese Stellen verweisen.

Gesundheitsdaten sind besonders schutzwürdig. Ergebnisse nur als Datei ausgeben und nicht öffentlich teilen oder veröffentlichen.

Sprache: Deutsch, sachlich und verständlich. Gegenüber Laien Fachbegriffe kurz erklären.

## Ablauf

### 1. Eckdaten erfassen
Fehlende Angaben kurz erfragen:
- Wer schreibt? Versicherte Person selbst, Angehörige mit Vollmacht, gesetzliche Betreuung, Eltern oder Pflegeeltern, Pflegeberatung
- Pflegekasse bzw. Versicherung (gesetzlich oder privat/Medicproof)
- Art des Verfahrens: Erstantrag, Höherstufung, Wiederholungsbegutachtung, Herabstufung oder Aufhebung (Anhörung nach § 24 SGB X, Aufhebung nach § 48 SGB X)
- Datum und Art der Begutachtung (Hausbesuch, telefonisch, nach Aktenlage)
- Datum des Bescheids, Zugang, Rechtsbehelfsbelehrung vorhanden? → Frist berechnen (siehe unten)
- Bisheriger und neuer Pflegegrad samt Punkten
- Kind? → Vergleich mit einem altersentsprechend entwickelten Kind (§ 15 Abs. 6 SGB XI). Bei Kindern bis 18 Monate Einstufung einen Pflegegrad höher (§ 15 Abs. 7 SGB XI).

Das Gutachten (meist PDF) vollständig lesen. Bei gescannten Seiten jede Seite ansehen. Keine Werte raten: Fehlendes als „im Gutachten nicht angegeben" markieren.

### 2. Bewertung aus dem Gutachten übernehmen
Jedes Kriterium mit dem Wert aus dem Gutachten in eine Tabelle übertragen. Dazu kurz den Befund- bzw. Begründungstext notieren, auf den sich die Bewertung stützt.

### 3. Punkte nachrechnen (immer per Code)
Einzelpunkte je Modul addieren → gewichtete Punkte nach Anlage 2 → Gesamtpunkte → Pflegegrad. Die Rechnung in Python ausführen, nicht im Kopf. Rechenfehler oder Abweichungen im Gutachten ausdrücklich benennen.

### 4. Inhaltliche Prüfung je Kriterium
- **Befund passt nicht zur Bewertung:** z. B. Befund „Gangunsicherheit, Rollator, Sturzneigung", Bewertung 1.4 „selbständig".
- **Widersprüche zwischen Modulen:** z. B. deutliche kognitive Einschränkungen in Modul 2, aber Module 4 und 6 weitgehend selbständig. Oder Demenzdiagnose, aber 2.8 „Erkennen von Risiken" unbeeinträchtigt.
- **Diagnosen und Unterlagen nicht berücksichtigt:** Arztberichte, Medikationsplan, Hilfsmittel, Entlassberichte.
- **Pflegeperson nicht befragt** oder Pflegetagebuch nicht berücksichtigt.
- **Häufigkeiten in Modul 3 und 5 zu niedrig:** Gegenbeweis mit einem Pflegetagebuch über mindestens 14 Tage.
- **Nur eine Momentaufnahme:** z. B. ein „guter Tag", schwankende Zustände, Nacht nicht erfasst.
- **Verfahrensmängel:** telefonische Begutachtung oder Aktenlage trotz komplexer Situation, auffällig kurze Begutachtung, fehlende Empfehlungen zu Hilfsmitteln oder Reha. Bei Herabstufung: Abweichung vom Vorgutachten ohne nachvollziehbare Verbesserung.
- **Besondere Bedarfskonstellation:** Gebrauchsunfähigkeit beider Arme und beider Beine → Pflegegrad 5 unabhängig von der Punktzahl.

Für jedes strittige Kriterium einen Gegenvorschlag mit Begründung machen. Danach neu rechnen, einmal realistisch und einmal vorsichtig. **Ehrlich einschätzen**, ob die Schwelle zum nächsten Pflegegrad erreichbar ist, und es klar sagen, wenn nicht. Überzogene Forderungen schwächen einen Widerspruch.

### 5. Kurzfazit zuerst im Chat
Punkte laut Gutachten, Punkte nach Nachrechnung, realistisch erreichbarer Pflegegrad, die 3–5 stärksten Argumente, Fristende. Dann fragen, ob das Schreiben erstellt werden soll und ob Angaben der Pflegeperson ergänzt werden können.

### 6. Schreiben als Word-Datei (.docx)
Aufbau:
1. Absender, Empfänger (Pflegekasse bzw. Versicherung), Datum, Betreff mit Versichertennummer und Bescheiddatum
2. Widerspruch fristwahrend einlegen. Akteneinsicht beantragen (§ 25 SGB X), einschließlich des vollständigen Gutachtens, falls es nicht vorliegt.
3. Antrag: Pflegegrad X ab Antragsdatum, hilfsweise erneute Begutachtung durch eine andere Gutachterin oder einen anderen Gutachter, mit Hausbesuch und Befragung der Pflegeperson
4. Begründung modulweise mit Vergleichstabelle: Kriterium | Bewertung im Gutachten | zutreffende Bewertung | Begründung
5. Punkteberechnung alt gegenüber neu (gewichtete Punkte je Modul, Gesamtpunkte)
6. Platzhalter [PFLEGETAGEBUCH: Beobachtungen der Pflegeperson einfügen] an den passenden Stellen
7. Anlagenverzeichnis (Pflegetagebuch, Arztberichte, Medikationsplan, Vollmacht oder Betreuerausweis)
8. Unterschrift

Rechtsgrundlagen nur zitieren, wenn sie zum Punkt passen: §§ 14, 15 SGB XI, § 18 ff. SGB XI (Begutachtungsverfahren), Begutachtungsrichtlinien (BRi) des Medizinischen Dienstes Bund, § 20 SGB X (Amtsermittlung), § 24 SGB X (Anhörung), § 25 SGB X (Akteneinsicht), § 48 SGB X (Aufhebung), § 84 SGG (Widerspruchsfrist). Im Zweifel die aktuelle Fassung im Web prüfen.

Optional anbieten: eine Vorlage für ein 14-tägiges Pflegetagebuch, zugeschnitten auf die strittigen Kriterien.

## Fristen
- **Widerspruch:** 1 Monat ab Bekanntgabe des Bescheids (§ 84 SGG). Ein per Post versandter Bescheid gilt am 4. Tag nach Aufgabe zur Post als bekanntgegeben (§ 37 Abs. 2 SGB X). Fällt das Fristende auf ein Wochenende oder einen Feiertag, endet die Frist am nächsten Werktag.
- **Fehlende oder falsche Rechtsbehelfsbelehrung:** 1 Jahr (§ 66 SGG).
- Ist die Zeit knapp, zuerst fristwahrend Widerspruch einlegen und die Begründung nachreichen.
- **Private Pflegeversicherung (Medicproof):** Es gibt kein Widerspruchsverfahren nach dem SGG. Stattdessen schriftlich Einwände beim Versicherer erheben und ein neues Gutachten verlangen. Danach bleibt die Klage vor dem Sozialgericht.

## Bewertungssystematik (Anlagen 1 und 2 zu § 15 SGB XI)

### Bewertungsskalen
- **Selbständigkeit (Module 1, 4, 6, sowie 5.16):** 0 = selbständig, 1 = überwiegend selbständig, 2 = überwiegend unselbständig, 3 = unselbständig
- **Modul 2 (Fähigkeiten):** 0 = vorhanden/unbeeinträchtigt, 1 = größtenteils vorhanden, 2 = in geringem Maße vorhanden, 3 = nicht vorhanden
- **Modul 3 (Häufigkeit):** 0 = nie oder sehr selten, 1 = selten (1–3× in 2 Wochen), 3 = häufig (2× bis mehrmals wöchentlich, nicht täglich), 5 = täglich

### Modul 1: Mobilität
1.1 Positionswechsel im Bett · 1.2 Halten einer stabilen Sitzposition · 1.3 Umsetzen · 1.4 Fortbewegen innerhalb des Wohnbereichs · 1.5 Treppensteigen (je 0–3)

### Modul 2: Kognitive und kommunikative Fähigkeiten
2.1 Erkennen von Personen aus dem näheren Umfeld · 2.2 örtliche Orientierung · 2.3 zeitliche Orientierung · 2.4 Erinnern an wesentliche Ereignisse oder Beobachtungen · 2.5 Steuern von mehrschrittigen Alltagshandlungen · 2.6 Treffen von Entscheidungen im Alltagsleben · 2.7 Verstehen von Sachverhalten und Informationen · 2.8 Erkennen von Risiken und Gefahren · 2.9 Mitteilen von elementaren Bedürfnissen · 2.10 Verstehen von Aufforderungen · 2.11 Beteiligen an einem Gespräch (je 0–3)

### Modul 3: Verhaltensweisen und psychische Problemlagen
3.1 motorisch geprägte Verhaltensauffälligkeiten · 3.2 nächtliche Unruhe · 3.3 selbstschädigendes und autoaggressives Verhalten · 3.4 Beschädigen von Gegenständen · 3.5 physisch aggressives Verhalten gegenüber anderen Personen · 3.6 verbale Aggression · 3.7 andere pflegerelevante vokale Auffälligkeiten · 3.8 Abwehr pflegerischer und anderer unterstützender Maßnahmen · 3.9 Wahnvorstellungen · 3.10 Ängste · 3.11 Antriebslosigkeit bei depressiver Stimmungslage · 3.12 sozial inadäquate Verhaltensweisen · 3.13 sonstige pflegerelevante inadäquate Handlungen (je 0/1/3/5)

### Modul 4: Selbstversorgung
| Kriterium | Punkte |
|---|---|
| 4.1 Waschen des vorderen Oberkörpers · 4.2 Körperpflege im Bereich des Kopfes · 4.3 Waschen des Intimbereichs · 4.4 Duschen und Baden einschl. Haarwäsche · 4.5 An- und Auskleiden des Oberkörpers · 4.6 An- und Auskleiden des Unterkörpers · 4.7 mundgerechtes Zubereiten der Nahrung und Eingießen von Getränken | 0 / 1 / 2 / 3 |
| 4.8 Essen | 0 / 3 / 6 / 9 |
| 4.9 Trinken | 0 / 2 / 4 / 6 |
| 4.10 Benutzen einer Toilette oder eines Toilettenstuhls | 0 / 2 / 4 / 6 |
| 4.11 Bewältigen der Folgen einer Harninkontinenz, Umgang mit Dauerkatheter und Urostoma | 0 / 1 / 2 / 3 |
| 4.12 Bewältigen der Folgen einer Stuhlinkontinenz, Umgang mit Stoma | 0 / 1 / 2 / 3 |
| 4.13 Ernährung parenteral oder über Sonde | entfällt 0 · teilweise 6 · vollständig 3 |

- 4.11 und 4.12 werden nur bewertet, wenn eine überwiegende oder vollständige Inkontinenz oder eine künstliche Ableitung besteht.
- 4.13 „entfällt", wenn die Sondenernährung nicht auf Dauer (voraussichtlich mindestens 6 Monate) nötig ist oder selbständig erfolgt.
- **4.K Kinder bis 18 Monate** (anstelle von 4.1–4.13): gravierende Probleme bei der Nahrungsaufnahme mit außergewöhnlich pflegeintensivem Hilfebedarf = 20 Punkte.

### Modul 5: Krankheits- und therapiebedingte Anforderungen
Gewertet werden nur Maßnahmen, die die Person **nicht selbständig** durchführen kann und die auf Dauer anfallen (voraussichtlich mindestens 6 Monate).

**5.1–5.7:** Medikation · Injektionen · Versorgung intravenöser Zugänge (z. B. Port) · Absaugen und Sauerstoffgabe · Einreibungen sowie Kälte- und Wärmeanwendungen · Messung und Deutung von Körperzuständen · körpernahe Hilfsmittel
→ Häufigkeiten aller Kriterien 5.1–5.7 auf einen Tagesdurchschnitt umrechnen (pro Woche ÷ 7, pro Monat ÷ 30) und addieren:

| Maßnahmen pro Tag (Summe 5.1–5.7) | Einzelpunkte |
|---|---|
| keine oder seltener als 1× täglich | 0 |
| 1× bis höchstens 3× täglich | 1 |
| mehr als 3× bis höchstens 8× täglich | 2 |
| mehr als 8× täglich | 3 |

**5.8–5.11:** Verbandswechsel und Wundversorgung · Versorgung mit Stoma · regelmäßige Einmalkatheterisierung und Nutzung von Abführmethoden · Therapiemaßnahmen in häuslicher Umgebung
→ Gleiche Umrechnung, Summe aus 5.8–5.11:

| Häufigkeit (Summe 5.8–5.11) | Einzelpunkte |
|---|---|
| keine oder seltener als 1× wöchentlich | 0 |
| 1× bis mehrmals wöchentlich | 1 |
| 1× bis unter 3× täglich | 2 |
| mindestens 3× täglich | 3 |

**5.12–5.15 (bei Kindern zusätzlich 5.K):** Werte je Kriterium berechnen und addieren:

| Kriterium | täglich | je Mal pro Woche | je Mal pro Monat |
|---|---|---|---|
| 5.12 zeit- und technikintensive Maßnahmen in häuslicher Umgebung | 60 | 8,6 | 2 |
| 5.13 Arztbesuche | – | 4,3 | 1 |
| 5.14 Besuch anderer medizinischer oder therapeutischer Einrichtungen (bis 3 Std.) | – | 4,3 | 1 |
| 5.15 zeitlich ausgedehnte Besuche (mehr als 3 Std.) | – | 8,6 | 2 |
| 5.K Besuche von Einrichtungen zur Frühförderung (Kinder) | – | 4,3 | 1 |

| Summe 5.12–5.15/5.K | Einzelpunkte |
|---|---|
| 0 bis unter 4,3 | 0 |
| 4,3 bis unter 8,6 | 1 |
| 8,6 bis unter 12,9 | 2 |
| 12,9 bis unter 60 | 3 |
| 60 und mehr | 6 |

**5.16** Einhalten einer Diät und anderer krankheits- oder therapiebedingter Verhaltensvorschriften: entfällt oder selbständig 0 · überwiegend selbständig 1 · überwiegend unselbständig 2 · unselbständig 3

Einzelpunkte Modul 5 = Punkte (5.1–5.7) + Punkte (5.8–5.11) + Punkte (5.12–5.15) + Punkte (5.16), maximal 15.

### Modul 6: Gestaltung des Alltagslebens und sozialer Kontakte
6.1 Gestaltung des Tagesablaufs und Anpassung an Veränderungen · 6.2 Ruhen und Schlafen · 6.3 Sichbeschäftigen · 6.4 Vornehmen von in die Zukunft gerichteten Planungen · 6.5 Interaktion mit Personen im direkten Kontakt · 6.6 Kontaktpflege zu Personen außerhalb des direkten Umfelds (je 0–3)

### Umrechnung in gewichtete Punkte (Anlage 2)
| Modul (Gewichtung) | keine | geringe | erhebliche | schwere | schwerste |
|---|---|---|---|---|---|
| M1 Mobilität (10 %) | 0–1 → 0 | 2–3 → 2,5 | 4–5 → 5 | 6–9 → 7,5 | 10–15 → 10 |
| M2 Kognition (15 %*) | 0–1 → 0 | 2–5 → 3,75 | 6–10 → 7,5 | 11–16 → 11,25 | 17–33 → 15 |
| M3 Verhalten (15 %*) | 0 → 0 | 1–2 → 3,75 | 3–4 → 7,5 | 5–6 → 11,25 | 7–65 → 15 |
| M4 Selbstversorgung (40 %) | 0–2 → 0 | 3–7 → 10 | 8–18 → 20 | 19–36 → 30 | 37–54 → 40 |
| M5 Krankheitsbezogene Anforderungen (20 %) | 0 → 0 | 1 → 5 | 2–3 → 10 | 4–5 → 15 | 6–15 → 20 |
| M6 Alltag und soziale Kontakte (15 %) | 0 → 0 | 1–3 → 3,75 | 4–6 → 7,5 | 7–11 → 11,25 | 12–18 → 15 |

\* Von den Modulen 2 und 3 zählt nur der höhere gewichtete Wert.

### Pflegegrade nach Gesamtpunkten
| Pflegegrad | Gesamtpunkte |
|---|---|
| PG 1 | 12,5 bis unter 27 |
| PG 2 | 27 bis unter 47,5 |
| PG 3 | 47,5 bis unter 70 |
| PG 4 | 70 bis unter 90 |
| PG 5 | 90 bis 100 (oder besondere Bedarfskonstellation) |

Stand der Tabellen: SGB XI, Anlagen 1 und 2 zu § 15 (geprüft im November 2026). Bei Hinweisen auf eine Gesetzesänderung die aktuelle Fassung im Web prüfen, z. B. mit der Suche „Anlage 1 zu § 15 SGB XI".

## Qualitätsregeln
- Jede Gegenbewertung braucht einen Beleg: Befundtext, Diagnose, Arztbericht, Pflegetagebuch oder Angabe der Pflegeperson.
- Nichts erfinden, nicht übertreiben, Erfolgsaussichten nüchtern einschätzen.
- Persönliche Daten nur im Schreiben verwenden und nicht öffentlich teilen.
- Bei rechtlich schwierigen Fragen auf Fachanwalt, Sozialverband oder Pflegestützpunkt verweisen.
